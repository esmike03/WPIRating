<!DOCTYPE html>
<html>

<head>
    <title>New Customer Form Submission</title>
</head>

<body style="color: black; font-family: Arial, sans-serif; line-height: 1.6; padding: 20px;">

    <h2 style="color: #2c3e50;">New Customer Form Submitted</h2>

    <!-- Two-column layout for personal info -->
    <table style="width: 100%; border-collapse: collapse;">
        <tr>
            <td style="padding: 8px;"><strong>Date:</strong> <?php echo e($data['date']); ?></td>
            <td style="padding: 8px;"><strong>Customer Code:</strong> <?php echo e($data['customer_code']); ?></td>
        </tr>
        <tr>
            <td style="padding: 8px;"><strong>Customer Name:</strong> <?php echo e($data['customer_name']); ?></td>
            <td style="padding: 8px;"><strong>Address:</strong> <?php echo e($data['address']); ?></td>
        </tr>
    </table>
    <?php
        $color = $data['average_rating'] >= 7 ? 'green' : ($data['average_rating'] >= 4 ? 'orange' : 'red');
    ?>

    <h1>Average Rating:
        <span style="font-weight: bold; color: <?php echo e($color); ?>;">
            <?php echo e($data['average_rating']); ?>

        </span>
    </h1>

    <p style="padding: 8px;"><strong>Comments and Remarks:</strong> <?php echo e($data['comments']); ?></p>
    <p style="text-align: center; margin-top: 20px; font-size: 12px; color: #7f8c8d;">
        <em>This is an automated email. Please do not reply.</em>
    </p>
    <table role="presentation" width="100%" cellspacing="0" cellpadding="0">
        <tr>
            <td align="center">
                <img src="https://i.imgur.com/LLLS3V2.png" alt="Logo" style="width: 100px; display: block;" />
            </td>
        </tr>
    </table>

    <hr style="border: 1px solid #ddd; margin: 20px 0;">

    <!-- Two-column section for categories -->
    <table style="width: 100%; border-collapse: collapse;">
        <tr>
            <td style="vertical-align: top; padding: 10px; width: 50%;">
                <h3 style="color: #2980b9;">Personal Relation</h3>
                <?php
                    $questions = [
                        'To Customers',
                        'To Agent and Partner',
                        'Loyalty to the Company',
                        'To the Manager of the Company',
                        'To the Supervisor',
                        'To the Office Feedback',
                        'Loyalty to the Company',
                    ];
                ?>
                <ul>

                    <?php $__currentLoopData = json_decode($data['personalrelation'], true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><span><?php echo e($questions[$key]); ?>:</span> <strong><?php echo e($value); ?></strong></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </td>

            <td style="vertical-align: top; padding: 10px; width: 50%;">
                <h3 style="color: #2980b9;">Sales and Collection</h3>
                <?php
                    $questions2 = ['Ordering Concerns', 'Terms Concerns', 'Deal Concerns', 'Discounting Concerns', 'Collection Concerns'];
                ?>
                <ul>
                    <?php $__currentLoopData = json_decode($data['sales'], true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><span><?php echo e($questions2[$key]); ?>:</span> <strong><?php echo e($value); ?></strong></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </td>
        </tr>


    </table>

</body>

</html>
<?php /**PATH D:\xampp\htdocs\ratingWeb\resources\views/emails/customer_form.blade.php ENDPATH**/ ?>